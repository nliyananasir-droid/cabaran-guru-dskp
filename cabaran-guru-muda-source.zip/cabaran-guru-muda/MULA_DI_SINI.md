# Cabaran Guru Muda: Misi DSKP

Source code permainan Checkpoint 4. Versi asal menggunakan React, TypeScript dan Vinext.

## Upload ke GitHub melalui pelayar
1. Extract ZIP ini.
2. Buka https://github.com/new dan namakan repository cabaran-guru-muda-dskp.
3. Pilih Public jika kod hendak dikongsi, atau Private untuk simpanan sendiri. Cipta repository.
4. Klik uploading an existing file (repository kosong), atau Add file > Upload files.
5. Upload kandungan folder cabaran-guru-muda, bukan ZIP atau folder induknya. package.json mesti berada di root repository.
6. GitHub menerima sehingga 100 fail setiap upload. Upload folder components dahulu dan commit; kemudian upload baki fail/folder dan commit sekali lagi.
7. Pastikan fail tersembunyi .gitignore, .npmrc dan folder .openai turut disertakan.

## Fail utama
- app/page.tsx: permainan, pergerakan, NPC, misi dan skor.
- app/globals.css: rupa dan susun atur responsif.
- public/: grafik sekolah dan watak.
- package.json dan pnpm-lock.yaml: kebergantungan projek.

## Pembangunan tempatan
Pasang Node.js >=22.13.0 dan pnpm versi yang dinyatakan dalam package.json.
Dalam terminal di folder projek:

    pnpm install --frozen-lockfile
    pnpm dev

Buka alamat tempatan yang dipaparkan dalam terminal. Sambungan internet diperlukan untuk memasang kebergantungan. Arahan ini berdasarkan konfigurasi projek; pemasangan pada komputer anda belum diuji.
README.md mengandungi penerangan teknikal starter asal. Ciri log masuk dan pangkalan data dalam starter tidak digunakan oleh permainan ini.

## GitHub dan GitHub Pages
Upload ini menyimpan source code. Ia tidak terus menerbitkan permainan di GitHub Pages.
Build asal menggunakan Vinext/Worker, bukan laman statik siap untuk GitHub Pages. Versi statik atau konfigurasi build yang sesuai diperlukan untuk mendapatkan pautan github.io.
Permainan yang sudah diterbitkan boleh dimainkan di:
https://cabaran-guru-muda-dskp.n-liyananasir.chatgpt.site

Pakej ini tidak mengandungi node_modules, cache, sejarah Git atau identiti deployment asal.
